**__Add the turtlebot3_final_project to your src.__**  
Dont forget to run Catkin_make after adding it!

**  
The problem is solved, then it can be run:**

1. __Launch turtlebot3_maze.launch__
2. __Launch turtlebot3_navigation.launch__

* On Rviz you can see how the path and curve are being planning. However, you should see Gazebo, where the real simulation is taking place.  
* Based on the documentation the laser we are using also present some inconsistency, even in simulation and also this can cause that the robot gets stuck sometime and gives up to reach the goal. 